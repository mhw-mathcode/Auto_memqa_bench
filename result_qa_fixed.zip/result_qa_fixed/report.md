# Narrative Memory Benchmark 数据集信息与可行性报告

## 1. 数据集概览

本数据集由 8 部长篇叙事作品构成，通过带 speaker 标注的连续 dialogue 构建记忆环境，并在其上设计单选、多选和排序 QA，用于评估模型对人物、事件、状态变化、关系、细节、经验与计划等信息的长期保持与推理能力。

### 1.1 Conversation 组织与 speaker 标注

每部作品的 `conversation` 都采用同一套核心结构：顶部使用连续的 `speaker_0`、`speaker_1`……登记实际出现的说话人；正文按 `session_N` 组织；每条 dialogue 统一只包含 `speaker`、`dia_id` 和 `text` 三个字段。`dia_id` 是作品内部唯一的原文定位键，QA 中的 `evidence_dialogues` 通过它回指 conversation。

### 1.2 总体规模

| 指标 | 数值 |
|---|---:|
| 作品数 | **8** |
| QA 总数 | **736** |
| QA ID 总数 | **736** |
| Dialogue units | **50,325** |
| 英文词数 | **约 664,431** |
| Session 总数 | **140** |
| Single-choice | **321（43.6%）** |
| Multiple-choice | **182（24.7%）** |
| Ordering | **233（31.7%）** |

---

## 2. 各作品信息

| 作品 | Session | Dialogue | Words | QA |
|---|---:|---:|---:|---:|
| 9-nine Episode 1 | 17 | 3,452 | 46,633 | 62 |
| A Kiss for the Petals | 1 | 1,862 | 24,172 | 46 |
| Arknights | 54 | 9,806 | 113,979 | 96 |
| fault milestone two side: above | 1 | 7,761 | 62,780 | 103 |
| Heart of the Woods | 1 | 4,406 | 106,667 | 116 |
| Highway Blossoms | 1 | 4,053 | 75,634 | 94 |
| Nurse Love Addiction | 61 | 7,714 | 95,996 | 117 |
| The House in Fata Morgana: A Requiem for Innocence | 4 | 11,271 | 138,570 | 102 |
| **合计** | **140** | **50,325** | **664,431** | **736** |

数据集同时包含多 session 长期轨迹，以及单 session 但长度达到数千条 dialogue 的连续叙事。同一个 session 可以包含数千条 dialogue，因此跨 session 不是长期记忆的必要条件；证据的全局 dialogue 距离比 session 数量更能直接反映记忆负担。

---

## 3. Category 分布

| Category | QA | 占比 |
|---|---:|---:|
| 1 — User Profile | 84 | 11.4% |
| 2 — Event-based | 187 | 25.4% |
| 3 — Temporal Evolution | 142 | 19.3% |
| 4 — Social Relationship & Interaction | 96 | 13.0% |
| 5 — Fine-grained Data | 103 | 14.0% |
| 6 — Experience / Lessons | 45 | 6.1% |
| 7 — Plans & Commitments | 79 | 10.7% |
| **合计** | **736** | **100.0%** |

Category 2 数量最多。Category 3、4、7 合计 **317 道，占 43.1%**，覆盖状态演化、人物关系以及计划与承诺，是长期记忆系统容易与普通局部检索拉开差异的部分。

Category 6 相对较少，因此正式实验建议同时报告 Overall Accuracy、Macro Category Accuracy 和各 Category Accuracy，避免 Event-based 类别的数量优势主导总体指标。

---

## 4. Label 分布

| Label | QA | 占比 |
|---|---:|---:|
| Fact Extraction (Multiple Dialogues) | 464 | 63.0% |
| Fact Extraction (Single Dialogue) | 98 | 13.3% |
| Abstain | 97 | 13.2% |
| Multi-hop | 51 | 6.9% |
| Memory Update | 26 | 3.5% |
| **合计** | **736** | **100.0%** |

Label 描述证据组织或推理形式：

- `Fact Extraction (Single Dialogue)`：答案由一个 dialogue 证据支持；
- `Fact Extraction (Multiple Dialogues)`：答案需要组合多个 dialogue 或叙事位置的信息；
- `Memory Update`：需要识别后续信息对早期状态的更新；
- `Multi-hop`：至少需要两个由证据支持的推理步骤；
- `Abstain`：A–E 均不可由文本推出，正确答案为 F。

`category`、`question_type` 与 `label` 分别描述能力类别、输出形式和证据/推理结构，三者是相互补充的维度。

---

# 5. 长程记忆难度分析

本报告使用三个相互补充的维度描述 memory load：

1. **Long-range Integration：长距离证据整合**
2. **Long-term Retention：信息长期保持**
3. **Cross-session Continuity：跨 session 状态连续性**

其中，前两个距离指标均基于完整 narrative 中的全局 dialogue 顺序，不要求证据跨 session。

## 5.1 长距离证据整合：Evidence Span

对于每道题，将所有 evidence dialogue 映射到完整叙事中的全局顺序位置，并定义：

> **Evidence Span = 最晚 evidence 的 dialogue index − 最早 evidence 的 dialogue index**

span = 1,000 表示回答同一道题所需的最早与最晚证据相隔约 1,000 条 dialogue。单 evidence 题的 span 记为 0。

### 整体跨度分布

| Evidence Span 阈值 | QA 数 | 占全部 QA |
|---|---:|---:|
| ≥ 10 dialogues | 436 | 59.2% |
| ≥ 25 | 370 | 50.3% |
| ≥ 50 | 325 | 44.2% |
| ≥ 100 | **258** | **35.1%** |
| ≥ 200 | 200 | 27.2% |
| ≥ 500 | **179** | **24.3%** |
| ≥ 1,000 | **156** | **21.2%** |
| ≥ 2,000 | **115** | **15.6%** |
| ≥ 5,000 | **38** | **5.2%** |

约三分之一的问题需要整合相隔至少 100 条 dialogue 的证据；超过五分之一的问题证据跨度达到 1,000 条 dialogue。单 session 的长篇故事同样可以形成很强的长期记忆压力。

## 5.2 多证据问题的跨度

736 道题中，**592 道题包含至少两条 evidence，占 80.4%**。

| 指标 | Dialogue Span |
|---|---:|
| Median | **61** |
| P75 | **1,187.8** |
| P90 | **3,834.8** |
| P95 | **5,998.6** |
| Maximum | **10,602** |

分布具有明显长尾：最难的四分之一问题跨度超过约 1,188 条 dialogue，最难的 10% 超过约 3,835 条 dialogue。

## 5.3 相对于故事长度的跨度

对 592 道多 evidence 问题，将 evidence span 除以对应故事的 dialogue 总数：

| Evidence 跨越故事比例 | QA 数 | 多证据题占比 |
|---|---:|---:|
| ≥ 1% | 304 | 51.4% |
| ≥ 5% | 198 | 33.4% |
| ≥ 10% | 178 | 30.1% |
| ≥ 25% | 142 | 24.0% |
| ≥ 50% | 101 | 17.1% |
| ≥ 75% | 55 | 9.3% |

约 17% 的多证据题要求联系横跨至少半部故事的信息，9.3% 横跨至少四分之三的故事。

---
